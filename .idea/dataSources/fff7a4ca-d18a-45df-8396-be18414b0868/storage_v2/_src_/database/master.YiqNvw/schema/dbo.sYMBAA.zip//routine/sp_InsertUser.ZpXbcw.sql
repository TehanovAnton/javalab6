CREATE PROCEDURE [dbo].[sp_InsertUser]
    @name nvarchar(50),
    @lastName nvarchar(50),
	@mail nvarchar(50),
	@birthDay date,
	@imageData varbinary(max)
AS
    insert into UserInfo(Name, LastName, Mail, Birthday, ImageData)
                values(@name, @lastName, @mail, @birthDay, @imageData)
go

